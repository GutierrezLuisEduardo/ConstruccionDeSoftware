cat > package.json << 'EOF'
{
  "name": "sva_law",
  "version": "8.0.0",
  "description": "",
  "license": "ISC",
  "author": "SVA LAW",
  "type": "commonjs",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1",
    "start": "node index.js"
  },
  "dependencies": {
    "@supabase/supabase-js": "^2.106.2",
    "bcryptjs": "^3.0.3",
    "body-parser": "^2.2.2",
    "connect-pg-simple": "^10.0.0",
    "dotenv": "^17.4.2",
    "ejs": "^5.0.2",
    "express": "^5.2.1",
    "express-session": "^1.19.0",
    "multer": "^2.1.1",
    "pg": "^8.20.0"
  }
}
EOF

printf "\n==============================================================================="
printf "\nCreado:"
printf "\n\tpackage.json\n\tscript 'npm start'\n\nTodas las librerías instaladas"
printf "\n===============================================================================\n"




cat > .env << 'EOF'
SESSION_SECRET=
DATABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
SUPABASE_URL=
SUPABASE_BUCKET=
SUPABASE_EVIDENCES_BUCKET=
EOF

printf "\n===============================================================================\n"
printf "Creado .env de variables de entorno"
printf "\n===============================================================================\n"




cat > .gitignore << 'EOF'
node_modules
.env
only_install_dependencies.sh
install_and_init.sh
listar_archivos.sh
desplegar_dirstree.sh
salida.txt
EOF

printf "\n===============================================================================\n"
printf "Creado archivo .gitignore:\n"
cat .gitignore
printf "\n===============================================================================\n"




cat > listar_archivos.sh << 'EOF'
#!/usr/bin/env bash
set -euo pipefail

# Parámetros
ROOT_DIR="${1:-.}"                       # directorio raíz (por defecto: directorio actual)
BLACKLIST_FILE="${2:-.gitignore}"        # por defecto: ./blacklist.txt en el directorio de ejecución
BLACKLIST_TYPE="${3:-glob}"              # "glob" (por defecto) o "regex"

# Normalizar ROOT_DIR a ruta sin barra final
ROOT_DIR="${ROOT_DIR%/}"

# Cargar blacklist en array
blacklist=()
if [[ -f "$BLACKLIST_FILE" ]]; then
  while IFS= read -r line; do
    # omitir líneas vacías y comentarios que empiezan con #
    [[ -z "$line" || "${line##\#}" != "$line" ]] && continue
    blacklist+=("$line")
  done < "$BLACKLIST_FILE"
fi

# Función para comprobar si una ruta relativa coincide con la blacklist
# Recibe: ruta_relativa
is_blacklisted() {
  local rel="$1"
  if [[ "${#blacklist[@]}" -eq 0 ]]; then
    return 1
  fi

  if [[ "$BLACKLIST_TYPE" == "glob" ]]; then
    for pat in "${blacklist[@]}"; do
      [[ -z "$pat" ]] && continue

      if [[ "$rel" == $pat || "$(basename "$rel")" == $pat ]]; then
        return 0
      fi

      if [[ "$pat" == ./* || "$pat" == /* ]]; then
        p="${pat#./}"
        if [[ "$rel" == $p || "$rel" == $p/* ]]; then
          return 0
        fi
      fi
    done
    return 1
  else
    for pat in "${blacklist[@]}"; do
      [[ -z "$pat" ]] && continue
      if [[ "$rel" =~ $pat ]]; then
        return 0
      fi
    done
    return 1
  fi
}

# Función para imprimir separador con el nombre del archivo
print_section_header() {
  local rel="$1"
  # Ancho del separador basado en la longitud del nombre (mínimo 20)
  local name_line=" $rel "
  local name_len=${#name_line}
  local width=$(( name_len > 20 ? name_len : 20 ))
  local border
  border=$(printf '%*s' "$width" '' | tr ' ' '=')
  printf '%s\n' "$border"
  printf '%s\n' "$name_line"
  printf '%s\n' "$border"
}

# Recorrer con find y procesar archivos (archivos regulares)
find "$ROOT_DIR" -type f -print0 | while IFS= read -r -d '' file; do
  # calcular ruta relativa respecto a ROOT_DIR
  rel="${file#"$ROOT_DIR"/}"
  [[ "$rel" == "$file" ]] && rel="$(basename "$file")"

  # comprobar blacklist completa
  if is_blacklisted "$rel"; then
    continue
  fi

  # comprobar cada componente de la ruta (para bloquear directorios)
  skip=0
  IFS='/' read -ra parts <<< "$rel"
  prefix=""
  for p in "${parts[@]}"; do
    prefix="${prefix:+$prefix/}$p"
    if is_blacklisted "$prefix"; then
      skip=1
      break
    fi
  done
  [[ $skip -eq 1 ]] && continue

  # Imprimir cabecera de sección (separadores) y luego contenido
  print_section_header "$rel"
  # Mostrar contenido (si es binario, evitar romper la salida; usar cat -- anyway)
  cat -- "$file" || true
  printf '\n'
done
EOF

chmod +x listar_archivos.sh

printf "\n===============================================================================\n"
printf "Creado y activado script de despliegue de archivos 'listar_archivos.sh'"
printf "\n===============================================================================\n"


cat > desplegar_dirstree.sh << 'EOF'
#!/usr/bin/env bash
# Uso: ./pruebas.sh [ruta]
ROOT="${1:-.}"

# Carga patrones desde .gitignore (ignora comentarios y líneas vacías)
IG_FILE="$ROOT/.gitignore"
PATTERNS=()
if [[ -f "$IG_FILE" ]]; then
  while IFS= read -r line; do
    line="${line%%#*}"            # quita comentarios
    line="${line%"${line##*[![:space:]]}"}" # rtrim
    line="${line#"${line%%[![:space:]]*}"}" # ltrim
    [[ -z "$line" ]] && continue
    PATTERNS+=("$line")
  done < "$IG_FILE"
fi

# Comprueba si git check-ignore está disponible y estamos en un repo
USE_GIT_CHECK=false
if command -v git >/dev/null 2>&1; then
  if git -C "$ROOT" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    USE_GIT_CHECK=true
  fi
fi

# función: path relativo desde ROOT, sin ./ al inicio
relpath() {
  local p="$1"
  p="${p#"$ROOT"/}"
  p="${p#./}"
  [[ -z "$p" ]] && p="."
  echo "$p"
}

# función: decide si se debe ignorar un path
is_ignored() {
  local p="$1"
  local rel
  rel=$(relpath "$p")
  if $USE_GIT_CHECK; then
    git -C "$ROOT" check-ignore -q -- "$rel" && return 0 || return 1
  fi
  for pat in "${PATTERNS[@]}"; do
    if [[ "$pat" == */ ]]; then
      local patdir="${pat%/}"
      [[ "$rel" == "$patdir" || "$rel" == "$patdir/"* ]] && return 0
    else
      if [[ "$rel" == $pat || "$rel" == $pat/* ]]; then
        return 0
      fi
    fi
  done
  return 1
}

# imprime árbol recursivo
print_tree() {
  local dir="$1"
  local prefix="$2"
  local entries
  mapfile -t entries < <(ls -A --group-directories-first -- "$dir" 2>/dev/null || ls -A -- "$dir" 2>/dev/null)
  local count=${#entries[@]}
  for i in "${!entries[@]}"; do
    local name="${entries[i]}"
    local path="$dir/$name"
    local last=$(( i == count-1 ))   # 1 si es el último, 0 si no
    local branch
    if (( last )); then branch="└── "; else branch="├── "; fi

    if [[ -d "$path" ]]; then
      if is_ignored "$path"; then
        printf "%s%s%s/ [IGNORED]\n" "$prefix" "$branch" "$name"
        continue
      fi
      printf "%s%s%s/\n" "$prefix" "$branch" "$name"
      if (( last )); then newpref="$prefix    "; else newpref="$prefix│   "; fi
      print_tree "$path" "$newpref"
    else
      printf "%s%s%s\n" "$prefix" "$branch" "$name"
    fi
  done
}

# salida: raíz
echo "$(basename "$ROOT")/"
print_tree "$ROOT" ""
EOF

chmod +x desplegar_dirstree.sh

printf "\n===============================================================================\n"
printf "Creado y activado script de despliegue de directorios 'desplegar_dirstree.sh'"
printf "\n===============================================================================\n"

npm init
npm install

printf "\n===============================================================================\n"
printf "Iniciado el proyecto de node e instaladas las librerías requeridas, especificadas en package.json"
printf "\n===============================================================================\n"


printf "\n\n\nEjecuta 'npm start' para iniciar el servidor con la aplicación\n\n\n\n\n"
